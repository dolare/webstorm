
import uuid

from django.db import models
from django.contrib.auth.models import User


class AbstractDatedObject(models.Model):
    date_created = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='+', null=True, blank=True)
    modified_by = models.ForeignKey(User, on_delete=models.SET_NULL, related_name='+', null=True, blank=True)

    class Meta:
        abstract = True
        default_permissions = ('add', 'change', 'delete', 'view_only')


class AbstractSimpleObject(AbstractDatedObject):
    object_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    name = models.CharField(max_length=40, null=False, unique=True)
    description = models.TextField(null=True, blank=True)

    class Meta(AbstractDatedObject.Meta):
        abstract = True
        ordering = [
            'name'
        ]

    def __str__(self):
        return "{0}".format(self.name)


class CurriculumUnit(AbstractSimpleObject):
    pass


class DegreeRef(AbstractSimpleObject):
    name = models.CharField(max_length=40, null=False)
    doctorate = models.NullBooleanField()
    dual_degree = models.NullBooleanField()

    def __str__(self):
        return "{0} - {1}".format(self.name, self.description)

    class Meta(AbstractSimpleObject.Meta):
        unique_together = ('name', 'description')


class DurationUnit(AbstractSimpleObject):
    pass


class EventType(AbstractSimpleObject):
    pass


class Exam(AbstractSimpleObject):
    active = models.NullBooleanField()
    pass


class InternationalEnglishTest(AbstractSimpleObject):
    active = models.NullBooleanField()
    pass


class InternalCode(AbstractSimpleObject):
    def __str__(self):
        return "{0}-{1}".format(self.name, self.description)


class Subject(AbstractSimpleObject):
    def __str__(self):
        return "{0} - {1}".format(self.name, self.description)


class SubSubject(AbstractSimpleObject):
    name = models.CharField(max_length=100, null=False)
    subject = models.ForeignKey(Subject, on_delete=models.PROTECT)

    def __str__(self):
        return "{0} - {1}".format(self.subject, self.name)

    class Meta(AbstractSimpleObject.Meta):
        unique_together = ('name', 'subject')


class TranscriptEvaluationProvider(AbstractSimpleObject):
    def __str__(self):
        return "{0} - {1}".format(self.name, self.description)


class TuitionUnit(AbstractSimpleObject):
    pass


class University(AbstractDatedObject):
    object_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=255)
    university_type = models.CharField(max_length=20, null=True, blank=True, default="private",
                                       choices=(
                                               ("Public", "public"),
                                               ("Private", "private"),
                                       ), verbose_name='University Type')
    abbreviation = models.CharField(max_length=20, null=True, blank=True)

    class Meta(AbstractDatedObject.Meta):
        verbose_name_plural = "Universities"

    def __str__(self):
        return "{0}".format(self.name)


class Campus(AbstractDatedObject):
    object_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    university = models.ForeignKey(University, on_delete=models.PROTECT)
    name = models.CharField(max_length=255, null=True, blank=True, verbose_name='Campus name')
    iped_index = models.CharField(max_length=255, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    city = models.CharField(max_length=50, null=True, blank=True)
    country = models.CharField(max_length=100, null=True, blank=True)
    region = models.CharField(max_length=100, null=True, blank=True)
    county = models.CharField(max_length=100, null=True, blank=True)
    postal = models.CharField(max_length=50, null=True, blank=True)

    class Meta(AbstractDatedObject.Meta):
        verbose_name_plural = "Campuses"

    def __str__(self):
        return "{0} - {1} - {2}".format(self.university, self.name, self.iped_index)


class UniversitySchool(AbstractDatedObject):
    _REGION=(('AL','Alabama,AL'),('AK','Alaska,AK'),('AZ','Arizona,AZ'),('AR','Arkansas,AR'),('CA','California,CA'),('CO','Colorado,CO'),('CT','Connecticut,CT'),
        ('DE','Delaware,DE'),('FL','Florida,FL'),('GA','Georgia,GA'),('HI','Hawaii,HI'),('ID','Idaho,ID'),('IL','Illinois,IL'),('IN','Indiana,IN'),
        ('IA','Iowa,IA'),('KS','Kansas,KS'),('KY','Kentucky,KY'),('LA','Louisiana,LA'),('ME','Maine,ME'),('MD','Marvland,MD'),('MA','Massachusetts,MA'),
        ('MI','Michigan,MI'),('MN','Minnesota,MN'),('MS','Mississippi,MS'),('MO','Missouri,MO'),('MT','Montana,MT'),('NE','Nebraska,NE'),('NV','Nevada,NV'),
        ('NH','New Hampshire,NH'),('NJ','New Jersey,NJ'),('NM','New Mexico,NM'),('NY','New York,NY'),('NC','North Carolina,NC'),('ND','North Dakota,ND'),('OH','Ohio,OH'),
        ('OK','Oklahoma,OK'),('OR','Oregon,OR'),('PA','Pennsylvania,PA'),('RI','Rhode Island,RI'),('SC','South Carolina,SC'),('SD','South Dakota,SD'),('TN','Tennessee,TN'),
        ('TX','Texas,TX'),('UT','Utah,UT'),('VT','Vermont,VT'),('VA','Virginia,VA'),('WA','Washington,WA'),('WV','West Virginia,WV'),('WI','Wisconsin,WI'),
        ('WY','Wyoming,WY'),('DC','District of Columbia,DC'),('AS','American Samoa,AS'),('GU','Guam,GU'),('MP','Northern Mariana Islands,MP'),('PR','Puerto Rico,PR'),('VI','U.S. Virgin Islands,VI'))

    object_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    ceeb = models.CharField(max_length=20, unique=True)
    university = models.CharField(max_length=255)
    university_foreign_key = models.ForeignKey(University, on_delete=models.PROTECT, related_name='+',
                                               null=True, blank=True, verbose_name='university')
    campus = models.ManyToManyField(Campus, blank=True, related_name='+')
    university_type = models.CharField(max_length=20, null=True, blank=True, default="private",
                                       choices=(
                                               ("Pu", "public"),
                                               ("Pr", "private"),
                                       ), verbose_name='University Type')
    school = models.CharField(max_length=255, null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    city = models.CharField(max_length=50, null=True, blank=True)
    country = models.CharField(max_length=100)
    region = models.CharField(choices=_REGION, max_length=100, null=True, blank=True)
    county = models.CharField(max_length=100, null=True, blank=True)
    postal = models.CharField(max_length=50, null=True, blank=True)
    school_homepage = models.URLField(null=True, blank=True)
    contact_email = models.CharField(max_length=100, null=True, blank=True)
    contact_phone = models.CharField(max_length=50, null=True, blank=True)
    apply_url = models.URLField(null=True, blank=True)
    campus_visit_url = models.URLField(null=True, blank=True)
    info_section_url = models.URLField(null=True, blank=True)

    class Meta(AbstractDatedObject.Meta):
        ordering = [
            'ceeb',
            'university_foreign_key',
            'school',
        ]

    def __str__(self):
        return "{0}: {1} - {2}".format(self.ceeb, self.university_foreign_key, self.school)


class Program(AbstractDatedObject):
    object_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    university_school = models.ForeignKey(UniversitySchool, on_delete=models.PROTECT)
    program_name = models.CharField(max_length=255)
    degree = models.ForeignKey(DegreeRef, on_delete=models.PROTECT)

    department = models.CharField(max_length=255, null=True, blank=True)
    subject = models.ManyToManyField(Subject, blank=True)
    sub_subject = models.ManyToManyField(SubSubject, blank=True)

    specialization = models.TextField(blank=True, null=True)
    highlights = models.TextField(blank=True, null=True)
    audience = models.TextField(blank=True, null=True, verbose_name='Program Objective')
    certification = models.TextField(blank=True, null=True)
    job_placement = models.TextField(blank=True, null=True)
    discontinued = models.NullBooleanField()
    misc = models.TextField(blank=True, null=True)

    url = models.URLField(max_length=512, null=True, blank=True, verbose_name='Program URL')
    homepage_url = models.URLField(max_length=512, null=True, blank=True,
                                   verbose_name='Parent URL(e.g. Department URL)')
    additional_url = models.URLField(max_length=512, null=True, blank=True,
                                     verbose_name='Handbook URL')
    parent_handbook_url = models.URLField(max_length=512, null=True, blank=True,
                                          verbose_name='Handbook Parent URL')
    program_faq_url = models.URLField(blank=True, null=True)
    stats_profile_url = models.URLField(max_length=512, null=True, blank=True,
                                        verbose_name='Admission Stats URL')
    admission_stats_parent_url = models.URLField(max_length=512, null=True, blank=True,
                                                 verbose_name='Admission Stats Parent URL')
    job_placement_url = models.URLField(max_length=512, null=True, blank=True,
                                        verbose_name='Job Placement URL')
    job_placement_parent_url = models.URLField(max_length=512, null=True, blank=True,
                                               verbose_name='Job Placement Parent URL')
    same_as = models.ForeignKey(UniversitySchool, on_delete=models.PROTECT, related_name='+',
                                null=True, blank=True)
    same_as_many = models.ManyToManyField(UniversitySchool, blank=True, related_name='+', null=True)
    online_program = models.BooleanField(default = False, verbose_name='Online Program')
    terminal_or_fs_degree = models.NullBooleanField(blank=True, verbose_name='Free Standing')

    class Meta(AbstractDatedObject.Meta):
        ordering = [
            'university_school',
            'program_name',
            'degree',
        ]
        unique_together = ('university_school', 'program_name', 'degree')

    def __str__(self):
        return "{0} - {1} - {2}".format(self.university_school, self.program_name, self.degree)

    def ceeb_code(self):
        return self.university_school.ceeb


class AbstractProgramBasedObject(AbstractDatedObject):
    program = models.OneToOneField(Program, primary_key=True)

    class Meta(AbstractDatedObject.Meta):
        abstract = True
        order_with_respect_to = 'program'

    def __str__(self):
        return "{0}".format(self.program)
        

class Cost(AbstractProgramBasedObject):
    online_program = models.BooleanField(default = False, verbose_name='Online Program')
    full_part_time = models.CharField(max_length=10, null=True, blank=True, verbose_name='Full or Part Time',
                                      choices=(
                                          ("F", "Full Time"),
                                          ("P", "Part Time"),
                                      ))
    terminal_or_fs_degree = models.NullBooleanField(blank=True, verbose_name='Free Standing')

    duration_min = models.DecimalField(max_digits=8, decimal_places=1, blank=True, null=True,
                                       verbose_name='Duration Average From')
    duration_max = models.DecimalField(max_digits=8, decimal_places=1, blank=True, null=True, verbose_name='To')
    durationtime_limit = models.DecimalField(max_digits=8,decimal_places=1,blank=True,null=True,
                                             verbose_name='Duration Time Limit')
    duration_unit = models.ForeignKey(DurationUnit, on_delete=models.PROTECT, related_name='+',
                                      blank=True, null=True)
    duration_conj = models.CharField(max_length=20, blank=True, null=True,
                                     choices=(
                                        ("in", "in"),
                                        ("plus", "plus"),
                                     ))
    duration_addl = models.DecimalField(max_digits=8, decimal_places=1, blank=True, null=True)
    duration_addl_unit = models.ForeignKey(DurationUnit, on_delete=models.PROTECT, related_name='+',
                                           blank=True, null=True)
    duration_notes = models.TextField(blank=True, null=True)
    duration_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                          blank=True, null=True)

    curriculum_unit = models.ForeignKey(CurriculumUnit, on_delete=models.PROTECT, related_name='+',
                                        blank=True, null=True)
    min_total_unit = models.CommaSeparatedIntegerField(max_length=50, blank=True, null=True)
    curriculum_notes = models.TextField(blank=True, null=True)
    curriculum_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                            blank=True, null=True)
    curriculum_url = models.URLField(blank=True, null=True, verbose_name='Curriculum URL')

    max_transfer_unit = models.IntegerField(blank=True, null=True, verbose_name='Max transfer (advanced standing) unit')
    transfer_unit_notes = models.TextField(blank=True, null=True)
    transfer_unit_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                               blank=True, null=True)

    tuition_unit = models.ForeignKey(TuitionUnit, on_delete=models.PROTECT, related_name='+',
                                     blank=True, null=True)
    tuition_per_unit = models.PositiveIntegerField(blank=True, null=True, verbose_name='Tuition in state (per unit)')
    tuition_per_unit_out_state = models.PositiveIntegerField(blank=True, null=True,
                                                             verbose_name='Tuition out of state (per unit)')
    fee_included = models.NullBooleanField()
    tuition_notes = models.TextField(blank=True, null=True)
    tuition_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                         blank=True, null=True)

    part_time = models.NullBooleanField(verbose_name='Part-time Available')
    part_time_notes = models.TextField(blank=True, null=True, verbose_name='Full or Part-time Notes')
    part_time_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                           blank=True, null=True, verbose_name='Full or Part-time Internal')
    part_time_url = models.URLField(blank=True, null=True, verbose_name='Full or Part-Time URL')

    master_thesis_or_equivalent = models.CharField(max_length=10, null=True, blank=True,
                                                   choices=(
                                                    ("Y", "Yes"),
                                                    ("N", "No"),
                                                    ("O", "Optional"),
                                                   ))
    thesis_notes = models.TextField(blank=True, null=True)
    thesis_url = models.URLField(blank=True, null=True)
    thesis_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                        blank=True, null=True)

    doctorate_dissertation_or_equivalent = models.CharField(max_length=10, null=True, blank=True,
                                                            choices=(
                                                             ("Y", "Yes"),
                                                             ("N", "No"),
                                                             ("O", "Optional"),
                                                            ))
    dissertation_notes = models.TextField(blank=True, null=True)
    dissertation_url = models.URLField(blank=True, null=True)
    dissertation_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                              blank=True, null=True)

    nitty_gritty_degree_duration_program_url = models.URLField(null=True)
    program_faq_url = models.URLField(blank=True, null=True)
    university_cost_url = models.URLField(blank=True, null=True, verbose_name='Cost URL at University Level')
    school_cost_url = models.URLField(blank=True, null=True, verbose_name='Cost URL at School Level')
    notes = models.TextField(blank=True, null=True)


class Duration(AbstractProgramBasedObject):
    full_part_time = models.CharField(max_length=10, null=True, blank=True, verbose_name='Full or Part Time',
                                      choices=(
                                          ("F", "Full Time"),
                                          ("P", "Part Time"),
                                      ))
    part_time = models.NullBooleanField(verbose_name='Part-time Available')
    part_time_notes = models.TextField(blank=True, null=True, verbose_name='Part-time Notes')
    part_time_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                           blank=True, null=True, verbose_name='Part-time Internal')
    part_time_url = models.URLField(blank=True, null=True, verbose_name='Part-Time URL')
    duration_min = models.DecimalField(max_digits=8, decimal_places=1, blank=True, null=True,verbose_name='Duration Average From')
    duration_max = models.DecimalField(max_digits=8, decimal_places=1, blank=True, null=True,verbose_name='To')
    durationtime_limit=models.DecimalField(max_digits=8,decimal_places=1,blank=True,null=True, verbose_name='Duration Time Limit')
    duration_unit = models.ForeignKey(DurationUnit, on_delete=models.PROTECT, related_name='+',
                                      blank=True, null=True)
    duration_conj = models.CharField(max_length=20, blank=True, null=True,
                                     choices=(
                                        ("in", "in"),
                                        ("plus", "plus"),
                                     ))
    duration_addl = models.DecimalField(max_digits=8, decimal_places=1, blank=True, null=True)
    duration_addl_unit = models.ForeignKey(DurationUnit, on_delete=models.PROTECT, related_name='+',
                                           blank=True, null=True)
    duration_notes = models.TextField(blank=True, null=True)
    duration_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                          blank=True, null=True)
    nitty_gritty_degree_duration_program_url = models.URLField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)


class Curriculum(AbstractProgramBasedObject):
    curriculum_unit = models.ForeignKey(CurriculumUnit, on_delete=models.PROTECT, related_name='+',
                                        blank=True, null=True)
    min_total_unit = models.CommaSeparatedIntegerField(max_length=50, blank=True, null=True)
    curriculum_notes = models.TextField(blank=True, null=True)
    curriculum_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                            blank=True, null=True)
    curriculum_url = models.URLField(blank=True, null=True, verbose_name='Curriculum URL')

    max_transfer_unit = models.IntegerField(blank=True, null=True)
    transfer_unit_notes = models.TextField(blank=True, null=True)
    transfer_unit_url = models.URLField(blank=True, null=True)
    transfer_unit_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                               blank=True, null=True)
    master_thesis_or_equivalent = models.CharField(max_length=10, null=True, blank=True,
                                                   choices=(
                                                    ("Y", "Yes"),
                                                    ("N", "No"),
                                                    ("O", "Optional"),
                                                   ))
    thesis_notes = models.TextField(blank=True, null=True)
    thesis_url = models.URLField(blank=True, null=True)
    thesis_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                        blank=True, null=True)

    doctorate_dissertation_or_equivalent = models.CharField(max_length=10, null=True, blank=True,
                                                   choices=(
                                                    ("Y", "Yes"),
                                                    ("N", "No"),
                                                    ("O", "Optional"),
                                                   ))
    dissertation_notes = models.TextField(blank=True, null=True)
    dissertation_url = models.URLField(blank=True, null=True)
    dissertation_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                        blank=True, null=True)


class Tuition(AbstractProgramBasedObject):
    tuition_unit = models.ForeignKey(TuitionUnit, on_delete=models.PROTECT, related_name='+',
                                     blank=True, null=True)
    tuition_per_unit = models.PositiveIntegerField(blank=True, null=True, verbose_name= 'Tuition in state (per unit)')
    tuition_per_unit_out_state = models.PositiveIntegerField(blank=True, null=True, verbose_name= 'Tuition out of state (per unit)')
    fee_included = models.NullBooleanField()
    tuition_notes = models.TextField(blank=True, null=True)
    tuition_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                         blank=True, null=True)
    university_cost_url = models.URLField(blank=True, null=True, verbose_name='Cost URL at University Level')
    school_cost_url = models.URLField(blank=True, null=True, verbose_name='Cost URL at School Level')


class Deadline(AbstractProgramBasedObject):
    _MONTH = (
        (1, "January"),
        (2, "February"),
        (3, "March"),
        (4, "April"),
        (5, "May"),
        (6, "June"),
        (7, "July"),
        (8, "August"),
        (9, "September"),
        (10, "October"),
        (11, "November"),
        (12, "December"),
    )

    _DAY = (
        (1, "1st"), (2, "2nd"), (3, "3rd"), (4, "4th"), (5, "5th"),
        (6, "6th"), (7, "7th"), (8, "8th"), (9, "9th"), (10, "10th"),
        (11, "11th"), (12, "12th"), (13, "13th"), (14, "14th"), (15, "15th"),
        (16, "16th"), (17, "17th"), (18, "18th"), (19, "19th"), (20, "20th"),
        (21, "21th"), (22, "22th"), (23, "23th"), (24, "24th"), (25, "25th"),
        (26, "26th"), (27, "27th"), (28, "28th"), (29, "29th"), (30, "30th"),
        (31, "31th"),
    )

    deadline_fall_early_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    deadline_fall_early_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    deadline_fall_late_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    deadline_fall_late_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    deadline_fall_notes = models.TextField(blank=True, null=True)
    deadline_fall_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                               blank=True, null=True)

    deadline_spring_early_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    deadline_spring_early_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    deadline_spring_late_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    deadline_spring_late_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    deadline_spring_notes = models.TextField(blank=True, null=True)
    deadline_spring_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                                 blank=True, null=True)

    deadline_summer_early_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    deadline_summer_early_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    deadline_summer_late_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    deadline_summer_late_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    deadline_summer_notes = models.TextField(blank=True, null=True)
    deadline_summer_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                                 blank=True, null=True)

    deadline_rolling = models.NullBooleanField()
    deadline_rolling_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                                  blank=True, null=True)

    scholarship_deadline_month = models.PositiveIntegerField(choices=_MONTH, blank=True, null=True)
    scholarship_deadline_day = models.PositiveIntegerField(choices=_DAY, blank=True, null=True)
    scholarship_deadline_notes = models.TextField(blank=True, null=True)

    application_notes = models.TextField(blank=True, null=True, verbose_name='Deadline Notes')

    deadline_url = models.URLField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)


class Requirement(AbstractProgramBasedObject):
    _GRADE = (
        ("A+", "A+"),
        ("A", "A"),
        ("A-", "A-"),
        ("B+", "B+"),
        ("B", "B"),
        ("B-", "B-"),
        ("C+", "C+"),
        ("C", "C"),
        ("C-", "C-"),
    )

    special_reqs = models.TextField(blank=True, null=True)

    apply_online = models.NullBooleanField()
    application_fee = models.PositiveIntegerField(blank=True, null=True)
    application_fee_notes = models.TextField(blank=True, null=True)
    application_fee_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                                 blank=True, null=True)
    application_fee_waiver = models.NullBooleanField()
    application_fee_waiver_notes = models.TextField(blank=True, null=True)

    transcript_for_application = models.CharField(max_length=20, null=True, blank=True,
                                                  choices=(
                                                            ("Y", "Yes"),
                                                            ("N", "No"),
                                                  ))
    transcript_type = models.CharField(max_length=20, null=True, blank=True,
                                       choices=(
                                                ("U", "Unofficial"),
                                                ("O", "Official"),
                                       ))
    official_transcript_for_enrollment = models.CharField(max_length=20, null=True, blank=True,
                                                          choices=(
                                                                    ("Y", "Yes"),
                                                                    ("N", "No"),
                                                          ))
    transcript_post_admin = models.NullBooleanField(verbose_name='official_transcript_for_enrollment')
    transcript_post_admin_notes = models.TextField(blank=True, null=True, verbose_name='Transcript Notes')
    transcript_post_admin_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                                       blank=True, null=True,
                                                       verbose_name='Transcript Internal')

    recommendation = models.PositiveIntegerField(blank=True, null=True)
    recommendation_notes = models.TextField(blank=True, null=True)
    recommendation_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                                blank=True, null=True)

    gpa_minimum = models.DecimalField(blank=True, null=True, max_digits=3, decimal_places=2, verbose_name='GPA Minimum')
    gpa_minimum_letter = models.CharField(max_length=2, null=True, blank=True,
                                          choices=_GRADE, verbose_name='or')
    gpa_average = models.DecimalField(blank=True, null=True, max_digits=3, decimal_places=2, verbose_name='GPA Average')
    gpa_average_letter = models.CharField(max_length=2, null=True, blank=True,
                                          choices=_GRADE, verbose_name='or')
    gpa_suggested = models.DecimalField(blank=True, null=True, max_digits=3, decimal_places=2,
                                        verbose_name='GPA Suggested')
    gpa_suggested_letter = models.CharField(max_length=2, null=True, blank=True,
                                            choices=_GRADE, verbose_name='or')
    gpa_notes = models.TextField(blank=True, null=True, verbose_name='GPA Notes')
    gpa_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                     blank=True, null=True, verbose_name='GPA Internal')

    exam_required = models.NullBooleanField()
    exam = models.ManyToManyField(Exam, blank=True, related_name='+')
    exam_notes = models.TextField(blank=True, null=True)
    exam_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                      blank=True, null=True)

    school_test = models.NullBooleanField()
    school_test_notes = models.TextField(blank=True, null=True)

    school_interview = models.NullBooleanField()
    school_interview_notes = models.TextField(blank=True, null=True)

    essays = models.TextField(blank=True, null=True)

    resume = models.CharField(max_length=20, null=True, blank=True,
                              choices=(
                                        ("Y", "Yes"),
                                        ("N", "No"),
                                        ("O", "Optional"),
                              ))
    resume_notes = models.TextField(blank=True, null=True)
    resume_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT, related_name='+',
                                        blank=True, null=True)

    sup_mat_writing_sample = models.CharField(max_length=20, null=True, blank=True,
                                              choices=(
                                                        ("Y", "Yes"),
                                                        ("N", "No"),
                                                        ("O", "Optional"),
                                              ), verbose_name='Supplemental Materials - Writing Sample')
    sup_mat_writing_sample_notes = models.TextField(blank=True, null=True,
                                                    verbose_name='Supplemental Materials - Writing Sample Notes')
    supplimental_materials_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                                        related_name='+', blank=True, null=True)
    sup_mat_portfolio = models.CharField(max_length=20, null=True, blank=True,
                                         choices=(
                                                    ("Y", "Yes"),
                                                    ("N", "No"),
                                                    ("O", "Optional"),
                                         ), verbose_name='Supplemental Materials - Portfolio')
    sup_mat_portfolio_notes = models.TextField(blank=True, null=True,
                                               verbose_name='Supplemental Materials - Portfolio Notes')

    intl_transcript = models.ManyToManyField(TranscriptEvaluationProvider, blank=True, related_name='+')
    intl_transcript_notes = models.TextField(blank=True, null=True)
    intl_transcript_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                                 related_name='+', blank=True, null=True)

    intl_lang_waiver = models.NullBooleanField()
    intl_lang_waiver_conditions = models.TextField(blank=True, null=True)
    intl_lang_waiver_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                                  related_name='+', blank=True, null=True)

    intl_english_test_required = models.NullBooleanField()
    intl_english_test = models.ManyToManyField(InternationalEnglishTest, blank=True, related_name='+')
    intl_english_test_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                                   related_name='+', blank=True, null=True)

    intl_toefl_reqs = models.TextField(blank=True, null=True)
    toefl_ibt = models.PositiveIntegerField(blank=True, null=True)
    toefl_ibt_reading = models.PositiveIntegerField(blank=True, null=True)
    toefl_ibt_listening = models.PositiveIntegerField(blank=True, null=True)
    toefl_ibt_speaking = models.PositiveIntegerField(blank=True, null=True)
    toefl_ibt_writing = models.PositiveIntegerField(blank=True, null=True)
    toefl_pbt = models.PositiveIntegerField(blank=True, null=True)
    toefl_twe = models.DecimalField(blank=True, null=True, max_digits=2, decimal_places=1)
    toefl_tse = models.DecimalField(blank=True, null=True, max_digits=2, decimal_places=1)
    toefl_cbt = models.PositiveIntegerField(blank=True, null=True)
    toefl_notes = models.TextField(blank=True, null=True)
    toefl_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                       related_name='+', blank=True, null=True)

    intl_ielts_reqs = models.DecimalField(blank=True, null=True, max_digits=2, decimal_places=1)
    intl_ielts_notes = models.TextField(blank=True, null=True)
    intl_ielts_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                            related_name='+', blank=True, null=True)

    intl_other = models.TextField(blank=True, null=True)

    program_req_url = models.URLField(blank=True, null=True)
    school_req_url = models.URLField(blank=True, null=True)
    intl_req_url = models.URLField(blank=True, null=True)


class Scholarship(AbstractProgramBasedObject):
    fully_funded = models.NullBooleanField()
    fully_funded_notes = models.TextField(blank=True, null=True)
    fully_funded_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                              related_name='+', blank=True, null=True)

    scholarship_avail = models.NullBooleanField()
    scholarship_notes = models.TextField(blank=True, null=True)
    scholarship_internal = models.ForeignKey(InternalCode, on_delete=models.PROTECT,
                                             related_name='+', blank=True, null=True)

    scholarship_program_specific_url = models.URLField(blank=True, null=True)
    scholarship_general_url = models.URLField(blank=True, null=True)


class ExpertNotes(AbstractProgramBasedObject):
    expert_notes = models.TextField(blank=True, null=True)


class AbstractProgramBasedForeignKeyObject(AbstractDatedObject):
    program = models.ForeignKey(Program, null=True, blank=True)

    class Meta(AbstractDatedObject.Meta):
        abstract = True
        order_with_respect_to = 'program'

    def __str__(self):
        return "{0}".format(self.program)


class ExpertAdditionalNote(AbstractProgramBasedForeignKeyObject):
    additional_note_type = models.CharField(max_length=20, null=True, blank=True,
                                            choices=(
                                                        ("dead_link", "dead link"),
                                                        ("typo", "typo"),
                                                        ("outdated_information", "outdated information"),
                                                        ("data_discrepancy", "data_discrepancy"),
                                                        ("sidebars", "sidebars"),
                                                        ("infinite_loop", "infinite loop"),
                                                        ("floating_page", "floating_page"),
                                                        ("confusing", "confusing and not clearly presented"),
                                                        ("other_expert_note", "other expert note"),
                                            ), verbose_name='Additional Notes')
    additional_note_url = models.URLField(blank=True, null=True)
    additional_note_url2 = models.URLField(blank=True, null=True)
    additional_note_url3 = models.URLField(blank=True, null=True)
    additional_note = models.TextField(blank=True, null=True)
