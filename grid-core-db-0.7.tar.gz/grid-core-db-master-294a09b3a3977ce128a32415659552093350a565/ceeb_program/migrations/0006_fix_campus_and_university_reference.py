
from __future__ import unicode_literals

from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('ceeb_program', '0005_auto_20160830_1017'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='campus',
            name='university'
        ),
        migrations.RemoveField(
            model_name='universityschool',
            name='campus'
        ),
        migrations.RemoveField(
            model_name='universityschool',
            name='university_foreign_key'
        ),

        migrations.AddField(
            model_name='campus',
            name='university',
            field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to='ceeb_program.University'),
        ),
        migrations.AddField(
            model_name='universityschool',
            name='campus',
            field=models.ManyToManyField(blank=True, related_name='_universityschool_campus_+', to='ceeb_program.Campus'),
        ),
        migrations.AddField(
            model_name='universityschool',
            name='university_foreign_key',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='+', to='ceeb_program.University', verbose_name='university'),
        ),
    ]
