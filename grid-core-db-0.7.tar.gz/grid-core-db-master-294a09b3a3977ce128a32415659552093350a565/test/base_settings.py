
# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os

# BASE_DIR is parent directory of directory hosting this setting file
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'pd2&8hmk$smo2_r3@i_wh2uia&lq36m&phkp=)xpba+p_2bpsi'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = [
    "127.0.0.1",
]


# Application definition

INSTALLED_APPS = (
    # 'django.contrib.admin',   # removed for "adminplus", see below
    'django.contrib.admin.apps.SimpleAdminConfig',  # added for "adminplus", see below
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # 3rd party libs
    'bootstrap3',
    'adminplus',    # add custom view to admin page, https://github.com/jsocol/django-adminplus

    # our apps
    'apps.account',
    'apps.ceeb_program',
    'apps.record_management',
    'apps.webpage_tracking',
)

MIDDLEWARE_CLASSES = (
    'django.middleware.security.SecurityMiddleware',
    # whitenoise must be above others except SecurityMiddleware
    'whitenoise.middleware.WhiteNoiseMiddleware',   # whitenoise, http://whitenoise.evans.io/
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

ROOT_URLCONF = 'urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
            os.path.join(BASE_DIR, 'templates'),
        ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'wsgi.application'

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True


STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'static')  # where "collectstatic" will store artifact to
STATICFILES_DIRS = (
    os.path.join(BASE_DIR, 'static_common'),
)
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
