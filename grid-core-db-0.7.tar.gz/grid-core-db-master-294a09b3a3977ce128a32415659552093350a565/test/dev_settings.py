
from .base_settings import *


# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = [
    "127.0.0.1",
]


# databas settings
try:
    db_pass = os.environ["DB_PASS"]
except KeyError:
    print("Error: environment variable DB_PASS must be set.")
    exit(1)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'ceebdev',
        'HOST': 'localhost',
        'PORT': '',
        'USER': 'localuser',
        'PASSWORD': db_pass,
    }
}

# Application definition

